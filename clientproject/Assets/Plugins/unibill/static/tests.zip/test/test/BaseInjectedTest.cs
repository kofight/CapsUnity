//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using Ninject;
using Uniject.Impl;
using Ninject.Modules;
using Unibill;

namespace Tests {

    public class BaseInjectedTest {

        protected IKernel kernel;

        protected object sceneScope;

        [SetUp]
        public void setup() {
            kernel = createNewKernel();
            sceneScope = new object();
        }

        protected IKernel createNewKernel () {

            NinjectModule module = getOverrideModule ();
            if (null != module) {
                return new StandardKernel (new UnityModule(), new TestModule(), module);
            }
            return new StandardKernel (new UnityModule(), new TestModule());
        }

        protected virtual Ninject.Modules.NinjectModule getOverrideModule() {
            return null;
        }

        private object getScope(Ninject.Activation.IContext context) {
            return sceneScope;
        }

        protected Biller instantiateAndInitialiseBiller() {
            var result = kernel.Get<Biller>();
            result.Initialise();
            return result;
        }
    }
}
