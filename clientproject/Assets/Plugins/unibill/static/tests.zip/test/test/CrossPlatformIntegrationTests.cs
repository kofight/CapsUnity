//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using NUnit.Framework;
using Ninject;
using Unibill.Impl;
using Unibill;

namespace Tests {

    [TestFixture(BillingPlatform.AppleAppStore)]
    [TestFixture(BillingPlatform.GooglePlay)]
    [TestFixture(BillingPlatform.AmazonAppstore)]
    public class CrossPlatformIntegrationTests : BaseInjectedTest {
        private BillingPlatform platform;
        public CrossPlatformIntegrationTests (BillingPlatform platform) {
            this.platform = platform;
        }

        [Test]
        public void testInitialise () {
            Assert.AreEqual(BillerState.INITIALISED, instantiateAndInitialiseBiller().State);
        }

        [Test]
        public void testInitialiseAndPurchase () {
            var biller = instantiateAndInitialiseBiller();
            biller.onPurchaseComplete += onPurchase;
            biller.purchase(biller.InventoryDatabase.AllConsumablePurchasableItems[0]);
            Assert.IsNotNull(item);
        }

        [Test]
        public void testPurchaseSubscription () {
            var biller = instantiateAndInitialiseBiller();
            biller.onPurchaseComplete += onPurchase;
            biller.purchase(biller.InventoryDatabase.AllSubscriptions[0]);
            Assert.IsNotNull(item);
            Assert.AreEqual(1, biller.getPurchaseHistory(biller.InventoryDatabase.AllSubscriptions[0]));
        }

        private PurchasableItem item;
        private void onPurchase (PurchasableItem item) {
            this.item = item;
        }

        protected override Ninject.Modules.NinjectModule getOverrideModule () {
            switch (platform) {
                case BillingPlatform.AppleAppStore:
                    return new StorekitModule(true);
                case BillingPlatform.GooglePlay:
                    return new GooglePlayTestModule(true);
                case BillingPlatform.AmazonAppstore:
                    return new AmazonModule(true);
            }
            throw new NotImplementedException();
        }
    }
}
