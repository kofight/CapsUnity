//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;

namespace Tests {
    public class FakeEditorUtil : Uniject.Editor.IEditorUtil {
        public string getAssetsDirectoryPath () {
            return "../../../../Assets";
        }

        public string guidToAssetPath (string guid) {
            return "Assets";
        }
    }
}
