//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;

namespace Tests {
    public class FakeLogger : Uniject.ILogger {
        #region ILogger implementation

        public void Log (string message) {
            Console.WriteLine(message);
        }

        public void Log (string message, params object[] formatArgs) {
            Console.WriteLine(string.Format(message, formatArgs));
        }

        public void LogWarning (string message, params object[] formatArgs) {
            Console.Error.WriteLine(string.Format(message, formatArgs));
        }

        public string prefix {
            get;
            set;
        }

        public void LogError(string message, params object[] args) {
            Console.Error.WriteLine(string.Format(message, args));
        }
        #endregion
    }
}
