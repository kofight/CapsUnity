//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using System.Collections.Generic;
using Uniject;
using UnityEngine;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Ninject;
using Moq;

namespace Tests {
    
    /// <summary>
    /// Mock resource loader.
    /// TODO: fix the ludicrous, broken file existence checking.
    /// </summary>
    public class FakeResourceLoader : IResourceLoader {
        
        private string assetsPath = Path.GetFullPath("../../../../Assets");
     
        private static List<string> knownExtensions = new List<string>() { ".ogg", ".wav", ".mat", ".mp3", ".physicMaterial" };
        private List<string> resourcePaths;
        
        public FakeResourceLoader() {
            getResourcePaths();
        }
        
        public Material loadMaterial(string path) {
            throw new NotImplementedException();
        }
        
        public AudioClip loadClip(string path) {
            throw new NotImplementedException();
        }
        
        public XDocument loadDoc(string path) {
            path += ".xml";
            return XDocument.Load(getPath(path));
        }
        
        public string ignore;
        public System.IO.TextReader openTextFile (string path) {
            if (ignore == null || !path.Contains(ignore)) {
                return new System.IO.StreamReader (getPath (path + ".xml"), false);
            }
            return new StringReader("");
        }

        public T loadResource<T>(string path) where T : UnityEngine.Object {
            throw new NotImplementedException();
        }

        private string getPath (string fragment) {
            foreach (var folder in resourcePaths) {
                var path = Path.Combine(folder, fragment);
                if (new FileInfo(path).Exists) {
                    return path;
                }
            }

            throw new FileNotFoundException(fragment);
        }

        private void getResourcePaths() {
            this.resourcePaths = Directory.GetDirectories(assetsPath, "*", SearchOption.AllDirectories).Where(x => new DirectoryInfo(x).Name.ToLower() == "resources").ToList();
        }
        
        private static bool exists(string filepath) {
            foreach (string extension in knownExtensions) {
                FileInfo file = new FileInfo (filepath + extension);
                if (file.Exists) {
                    return true;
                }
            }
            
            return false;
        }

    }
}

