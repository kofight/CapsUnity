//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using System.Collections.Generic;

namespace Tests {
    public class FakeStorage  : Uniject.IStorage {
        private Dictionary<string, int> map = new Dictionary<string, int>();
        #region IStorage implementation

        public int GetInt (string key, int defaultValue) {
            if (map.ContainsKey (key)) {
                return map[key];
            }
            return defaultValue;
        }

        public void SetInt (string key, int value) {
            map[key] = value;
        }

        #endregion
    }
}

