//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using Uniject;

namespace Tests {
    public class FakeUtil : IUtil {
        #region IUtil implementation

        public T[] getAnyComponentsOfType<T> () where T : class {
            throw new NotImplementedException ();
        }

        public string loadedLevelName () {
            throw new NotImplementedException ();
        }

        public UnityEngine.RuntimePlatform Platform {
            get { return UnityEngine.RuntimePlatform.Android; }
        }

        public string persistentDataPath {
            get { return string.Empty; }
        }

        public DateTime currentTime {
            get { return DateTime.Now; }
        }

        #endregion
    }
}
