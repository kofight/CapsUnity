//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using Ninject;
using Ninject.Modules;
using Unibill;
using Unibill.Impl;

namespace Tests {
    public class GooglePlayTestModule : NinjectModule {
        private bool functional;
        public GooglePlayTestModule(bool functional) { 
            this.functional = functional;
        }

        public override void Load () {
            Rebind<IBillingService>().To<GooglePlayBillingService>().InSingletonScope();
            Rebind<IRawGooglePlayInterface>().To<FakeGooglePlayPlugin>().InSingletonScope();
            ((FakeGooglePlayPlugin) Kernel.Get<IRawGooglePlayInterface>()).available = functional;
        }
    }
}

