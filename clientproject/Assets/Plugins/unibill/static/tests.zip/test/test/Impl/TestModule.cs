//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using Uniject;
using Unibill.Impl;

namespace Tests {
    public class TestModule : Ninject.Modules.NinjectModule {
        
        public override void Load() {
            Rebind<IResourceLoader>().To<FakeResourceLoader>().InSingletonScope();
            Rebind<IStorage>().To<FakeStorage>().InSingletonScope();
            Rebind<ILogger>().To<FakeLogger>().InSingletonScope();
            Rebind<IBillingService>().To<FakeBillingService>().InSingletonScope();
            Rebind<Uniject.Editor.IEditorUtil>().To<FakeEditorUtil>().InSingletonScope();
            Rebind<IUtil>().To<FakeUtil>().InSingletonScope();
        }
    }
}
