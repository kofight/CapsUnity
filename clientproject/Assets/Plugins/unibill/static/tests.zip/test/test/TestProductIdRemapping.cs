//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using NUnit.Framework;
using Ninject;
using System;
using Unibill.Impl;

namespace Tests {

    [TestFixture]
    public class TestProductIdRemapping :BaseInjectedTest {

        [Test]
        public void testIdDefaultsToAgnosticId() {
            PurchasableItem item = kernel.Get<InventoryDatabase>().getItemById(testInventoryDatabase.TEST_CONSUMABLE_ID);
            ProductIdRemapper remapper = kernel.Get<ProductIdRemapper>();
            remapper.initialiseForPlatform(BillingPlatform.AppleAppStore);
            Assert.AreEqual(item.Id, remapper.mapItemIdToPlatformSpecificId(item));
        }

        [Test]
        public void testRemappedId() {
            ProductIdRemapper remapper = kernel.Get<ProductIdRemapper>();
            remapper.initialiseForPlatform(BillingPlatform.GooglePlay);
            PurchasableItem item = kernel.Get<InventoryDatabase>().getItemById(testInventoryDatabase.TEST_CONSUMABLE_ID);
            Assert.AreEqual("com.outlinegames.100goldcoins.v2", remapper.mapItemIdToPlatformSpecificId(item));
            Assert.AreEqual(item, remapper.getPurchasableItemFromPlatformSpecificId("com.outlinegames.100goldcoins.v2"));
        }
    }
}
