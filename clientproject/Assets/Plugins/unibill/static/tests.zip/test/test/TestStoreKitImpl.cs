//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using Unibill;
using Unibill.Impl;
using Ninject;
using Ninject.Modules;

namespace Tests {
    public class TestStoreKitImpl : BaseInjectedTest {

        [TestFixtureSetUp]
        public void testSetup() {
            setup();
        }

        [Test]
        public void testStorekitReportsBillingUnavailable() {
            ((FakeStorekitPlugin) kernel.Get<IStoreKitPlugin>()).available = false;
            Biller biller = instantiateAndInitialiseBiller();
            Assert.IsFalse(biller.Ready);
            Assert.AreEqual(BillerState.INITIALISED_WITH_CRITICAL_ERROR, biller.State);
            Assert.Greater(biller.Errors.Count, 0);
        }

        [Test]
        public void testStorekitUnableToRetrieveProductList() {
            ((FakeStorekitPlugin) kernel.Get<IStoreKitPlugin>()).functional = false;
            var biller = instantiateAndInitialiseBiller();
            var storekitService = (AppleAppStoreBillingService) biller.billingSubsystem;
            storekitService.onFailedToRetrieveProductList();
            Assert.AreEqual(BillerState.INITIALISED_WITH_ERROR, biller.State);
            Assert.Greater(biller.Errors.Count, 0);
        }

        [Test]
        public void testNilProductListReturned() {

            ((FakeStorekitPlugin) kernel.Get<IStoreKitPlugin>()).functional = false;
            Biller biller = instantiateAndInitialiseBiller();
            Assert.IsFalse(biller.Ready);

            AppleAppStoreBillingService svc = (AppleAppStoreBillingService) biller.billingSubsystem;

            svc.onProductListReceived("");
            Assert.IsFalse(biller.Ready);
            Assert.AreEqual(BillerState.INITIALISED_WITH_CRITICAL_ERROR, biller.State);
            Assert.Greater(biller.Errors.Count, 0);
        }

        [Test]
        public void testIncompleteProductListReturned() {
            Biller biller = instantiateAndInitialiseBiller();
            AppleAppStoreBillingService svc = (AppleAppStoreBillingService) biller.billingSubsystem;

            string products = string.Join(",", getAllProductIds(biller).GetRange(0, 1));
            svc.onProductListReceived(products);
            
            Assert.True(biller.Ready);
            Assert.AreEqual(BillerState.INITIALISED_WITH_ERROR, biller.State);
            Assert.Greater(biller.Errors.Count, 0);
        }

        [Test]
        public void testCompleteProductListReturned() {
            Biller biller = instantiateAndInitialiseBiller();
            AppleAppStoreBillingService svc = (AppleAppStoreBillingService) biller.billingSubsystem;

            string products = string.Join(",", getAllProductIds(biller));
            svc.onProductListReceived(products);

            Assert.AreEqual(0, biller.Errors.Count);
            Assert.AreEqual(BillerState.INITIALISED, biller.State);
            Assert.True(biller.Ready);
        }

        [Test]
        public void testSuccessfulPurchase () {
            Biller biller = instantiateAndInitialiseBiller();
            AppleAppStoreBillingService svc = (AppleAppStoreBillingService) biller.billingSubsystem;
            svc.onPurchaseSucceeded(testInventoryDatabase.TEST_CONSUMABLE_ID);

            Assert.AreEqual(1, biller.getPurchaseHistory(testInventoryDatabase.TEST_CONSUMABLE_ID));
        }

        [Test]
        public void testFailedPurchase () {
            Biller biller = instantiateAndInitialiseBiller();
            AppleAppStoreBillingService svc = (AppleAppStoreBillingService) biller.billingSubsystem;
            svc.onPurchaseFailed(testInventoryDatabase.TEST_CONSUMABLE_ID);
            
            Assert.AreEqual(0, biller.getPurchaseHistory(testInventoryDatabase.TEST_CONSUMABLE_ID));
        }

        [Test]
        public void testTransactionsRestored () {
            Biller biller = instantiateAndInitialiseBiller();
            Assert.AreEqual(0, biller.getPurchaseHistory(getNonConsumable()));
            biller.restoreTransactions();
            Assert.AreEqual(1, biller.getPurchaseHistory(getNonConsumable()));
        }

        [Test]
        public void testAttemptingToBuyProductNotReturnedByStorekit () {
            var biller = instantiateAndInitialiseBiller();
            var svc = (AppleAppStoreBillingService) biller.billingSubsystem;
            var ids = new List<string> (kernel.Get<ProductIdRemapper>().getAllPlatformSpecificProductIds());
            string unknown = ids[0];
            ids.RemoveAt(0);

            svc.onProductListReceived(string.Join(",", ids.ToArray()));

            biller.purchase(biller.InventoryDatabase.getItemById(unknown));
            Assert.AreEqual(2, biller.Errors.Count);
        }

        protected override NinjectModule getOverrideModule() {
            return new StorekitModule(true);
        }

        private PurchasableItem getNonConsumable() {
            return kernel.Get<InventoryDatabase>().AllNonConsumablePurchasableItems[0];
        }

        private List<string> getAllProductIds(Biller biller) {
            ProductIdRemapper mapper = kernel.Get<ProductIdRemapper>();

            return biller.InventoryDatabase.AllPurchasableItems.Select(x => mapper.mapItemIdToPlatformSpecificId(x)).ToList();
        }
    }
}
