//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using System.Linq;
using System.Collections.Generic;
using Ninject;
using NUnit.Framework;
using Unibill;
using Unibill.Impl;
using Moq;

namespace Tests {
    public class testAmazonBillingService : BaseInjectedTest {
    
        private ProductIdRemapper remapper;
        private InventoryDatabase db;

        [TestFixtureSetUp]
        public void testSetup () {
            setup();
            this.remapper = kernel.Get<ProductIdRemapper>();
            this.db = kernel.Get<InventoryDatabase>();
        }

        [Test]
        public void testGetItemDataReturnsNoAvailableProducts() {
            var biller = instantiateAndInitialiseBiller();
            AmazonAppStoreBillingService amazon = (AmazonAppStoreBillingService) biller.billingSubsystem;
            amazon.onProductListReceived(string.Empty);
            Assert.AreEqual(BillerState.INITIALISED_WITH_CRITICAL_ERROR, biller.State);
        }

        [Test]
        public void testGetItemDataFailed() {
            var biller = instantiateAndInitialiseBiller();
            AmazonAppStoreBillingService amazon = (AmazonAppStoreBillingService) biller.billingSubsystem;
            amazon.onGetItemDataFailed();
            Assert.AreEqual(BillerState.INITIALISED_WITH_ERROR, biller.State);
        }

        [Test]
        public void testGetItemDataReturnedPartialProductList() {
            var biller = instantiateAndInitialiseBiller();
            AmazonAppStoreBillingService amazon = (AmazonAppStoreBillingService) biller.billingSubsystem;
            List<string> products = getAllProductIds(biller);
            products.RemoveAt(0);
            amazon.onProductListReceived(string.Join(",", products.ToArray()));
            Assert.AreEqual(BillerState.INITIALISED_WITH_ERROR, biller.State);
        }

        [Test]
        public void testGetItemDataReturnedCompleteProductList() {
            var biller = instantiateAndInitialiseBiller();
            AmazonAppStoreBillingService amazon = (AmazonAppStoreBillingService) biller.billingSubsystem;
            amazon.onProductListReceived(string.Join(",", getAllProductIds(biller).ToArray()));
            Assert.AreEqual(BillerState.INITIALISED, biller.State);
        }

        [Test]
        public void testPurchaseFailed() {
            AmazonAppStoreBillingService amazon = kernel.Get<AmazonAppStoreBillingService>();
            var callback = new Mock<IBillingServiceCallback>();
            amazon.initialise(callback.Object);
            var item = db.AllConsumablePurchasableItems[0];
            amazon.onPurchaseFailed(remapper.mapItemIdToPlatformSpecificId(item));
            callback.Verify(x => x.onPurchaseFailedEvent(It.Is<string>(p => p.Equals(remapper.mapItemIdToPlatformSpecificId(item)))));
        }

        [Test]
        public void testPurchaseSucceeded() {
            AmazonAppStoreBillingService amazon = kernel.Get<AmazonAppStoreBillingService>();
            var callback = new Mock<IBillingServiceCallback>();
            amazon.initialise(callback.Object);
            var item = db.AllConsumablePurchasableItems[0];
            amazon.onPurchaseSucceeded(remapper.mapItemIdToPlatformSpecificId(item));
            callback.Verify(x => x.onPurchaseSucceeded(It.Is<string>(p => p.Equals(remapper.mapItemIdToPlatformSpecificId(item)))));
        }

        /// <summary>
        /// PurchaseUpdatesRequest is used to tell us about items that the user no longer has,
        /// eg they were refunded, and any items they have bought.
        /// The plugin sends us these as pipe separated comma delimited lists, the first of 
        /// which is revoked items, the second is purchased.
        /// </summary>
        [Test]
        public void testParsesRevokedAndValidSKUsFromPurchaseUpdatesRequest () {
            List<string> revoked = new List<string>();
            List<string> purchased = new List<string>();
            string data = "mary,had|a,little";
            AmazonAppStoreBillingService.parsePurchaseUpdates(revoked, purchased, data);
            Assert.AreEqual(revoked, new List<string> { "mary", "had" });
            Assert.AreEqual(purchased, new List<string> {"a", "little" });
        }

        [Test]
        public void testParsesEmptyLists () {
            List<string> revoked = new List<string>();
            List<string> purchased = new List<string>();
            AmazonAppStoreBillingService.parsePurchaseUpdates(revoked, purchased, "|");
            Assert.AreEqual(revoked, new List<string>());
            Assert.AreEqual(purchased, new List<string>());
        }

        [Test]
        public void testPurchaseUpdatesRequestFailed() {
            AmazonAppStoreBillingService svc = kernel.Get<AmazonAppStoreBillingService>();
            svc.onPurchaseUpdateFailed();
        }

        [Test]
        public void testPurchaseUpdatesWithRevokedProduct() {
            var biller = new Mock<IBillingServiceCallback>();
            AmazonAppStoreBillingService svc = kernel.Get<AmazonAppStoreBillingService>();
            svc.initialise(biller.Object);
            
            var item = db.AllNonConsumablePurchasableItems[0];
            List<string> items = new List<string>() { remapper.mapItemIdToPlatformSpecificId(item) };
            svc.onPurchaseUpdateSucceeded(items, new List<string>());

            biller.Verify(x => x.onPurchaseRefundedEvent(It.Is<string>(val => val.Equals(remapper.mapItemIdToPlatformSpecificId(item)))));
        }

        [Test]
        public void testPurchaseUpdatesWithPurchasedProduct() {
            var biller = new Mock<IBillingServiceCallback>();
            AmazonAppStoreBillingService svc = kernel.Get<AmazonAppStoreBillingService>();
            svc.initialise(biller.Object);

            var item = db.AllNonConsumablePurchasableItems[0];
            List<string> items = new List<string>() { remapper.mapItemIdToPlatformSpecificId(item) };
            svc.onPurchaseUpdateSucceeded(new List<string>(), items);

            biller.Verify(x => x.onPurchaseSucceeded(It.Is<string>(val => val.Equals(remapper.mapItemIdToPlatformSpecificId(item)))));
        }

        [Test]
        public void testAttemptingToBuyProductNotReturnedByAmazon () {
            var biller = instantiateAndInitialiseBiller();
            var svc = (AmazonAppStoreBillingService) biller.billingSubsystem;
            var ids = new List<string> (kernel.Get<ProductIdRemapper>().getAllPlatformSpecificProductIds());
            string unknown = ids[0];
            ids.RemoveAt(0);
            
            svc.onProductListReceived(string.Join(",", ids.ToArray()));
            
            biller.purchase(biller.InventoryDatabase.getItemById(unknown));
            Assert.AreEqual(2, biller.Errors.Count);
        }

        private List<string> getAllProductIds(Biller biller) {
            ProductIdRemapper mapper = kernel.Get<ProductIdRemapper>();
            
            return biller.InventoryDatabase.AllPurchasableItems.Select(x => mapper.mapItemIdToPlatformSpecificId(x)).ToList();
        }

        protected override Ninject.Modules.NinjectModule getOverrideModule () {
            return new AmazonModule(true);
        }
    }
}
