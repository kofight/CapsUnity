//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using System.Collections.Generic;
using Unibill;
using NUnit.Framework;
using Ninject;

namespace Tests {
    public class testAmazonJSONEncoding : BaseInjectedTest {
        [Test]
        public void testEncodeAll() {
            kernel.Get<AmazonJSONGenerator>().encodeAll();
        }
    }
}
