//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using NUnit.Framework;
using System.Xml;
using System.Xml.Linq;
using Uniject;
using Ninject;
using Uniject.Editor;
using Unibill.Impl;

using System.Xml.XPath;
using System.Collections.Generic;

namespace Tests {
    public class testAndroidManifestMerger : BaseInjectedTest, IXmlNamespaceResolver {

        private string[] COMMON_PERMISSIONS = {
            "manifest/uses-permission[@android:name='android.permission.INTERNET']",
        };

        private string[] GOOGLEPLAY_PERMISSIONS = {
            "manifest/uses-permission[@android:name='com.android.vending.BILLING']",
            "manifest/application/service[@android:name='com.outlinegames.unibill.BillingService']",
            "manifest/application/receiver[@android:name='com.outlinegames.unibill.BillingReceiver']",        
        };

        private string[] AMAZON_PERMISSIONS = {
            "manifest/application/receiver[@android:name='com.amazon.inapp.purchasing.ResponseReceiver']",
            "manifest/application/receiver[@android:name=\'com.amazon.inapp.purchasing.ResponseReceiver\']/intent-filter/action[@android:name=\'com.amazon.inapp.purchasing.NOTIFY\']",
        };

        private string[] AMAZON_SANDBOX_PERMISSIONS = {
            "manifest/uses-permission[@android:name='android.permission.WRITE_EXTERNAL_STORAGE']",
        };

        [Test]
        public void testGooglePlay () {
            XDocument doc = doDoubleMerge(BillingPlatform.AmazonAppstore, true);
            doc = doMerge(doc, BillingPlatform.GooglePlay, false);
            assertContains(doc, GOOGLEPLAY_PERMISSIONS);
            assertContains(doc, COMMON_PERMISSIONS);
            assertAbsent(doc, AMAZON_PERMISSIONS);
        }

        [Test]
        public void testAmazonLive () {
            XDocument doc = doDoubleMerge(BillingPlatform.AmazonAppstore, false);
            assertContains(doc, AMAZON_PERMISSIONS);
            assertContains(doc, COMMON_PERMISSIONS);
            assertAbsent(doc, GOOGLEPLAY_PERMISSIONS);
            assertAbsent(doc, AMAZON_SANDBOX_PERMISSIONS);
        }

        [Test]
        public void testAmazonSandbox () {
            XDocument doc = doDoubleMerge(BillingPlatform.AmazonAppstore, true);
            assertContains(doc, AMAZON_PERMISSIONS);
            assertContains(doc, COMMON_PERMISSIONS);
            assertAbsent(doc, GOOGLEPLAY_PERMISSIONS);
            assertContains(doc, AMAZON_SANDBOX_PERMISSIONS);
        }

        private XDocument doDoubleMerge (BillingPlatform platform, bool sandbox) {
            return doMerge(doMerge(loadRawManifest(), platform, sandbox), platform, sandbox);
        }

        private void assertAbsent (XDocument doc, string[] xpaths) {
            foreach (var xpath in xpaths) {
                Assert.Null(doc.XPathSelectElement(xpath, this));
            }
        }

        private void assertContains (XDocument doc, string[] xpaths) {
            Console.Error.Write(doc);
            foreach (var xpath in xpaths) {
                var els = new List<XElement> (doc.XPathSelectElements (xpath, this));
                Assert.AreEqual (1, els.Count, "Expected single:" + xpath);
            }
        }

        private XDocument doMerge (XDocument forDoc, BillingPlatform platform, bool sandbox) {
            AndroidManifestMerger merger = kernel.Get<AndroidManifestMerger>();
            return merger.merge(forDoc, platform, sandbox);
        }

        private XDocument loadRawManifest() {
            string rawPath = System.IO.Path.Combine(kernel.Get<IEditorUtil>().getAssetsDirectoryPath(), "Plugins/unibill/static/Manifest.xml");
            return XDocument.Load(rawPath);
        }

        #region IXmlNamespaceResolver implementation
        
        public System.Collections.Generic.IDictionary<string, string> GetNamespacesInScope (XmlNamespaceScope scope) {
            throw new NotImplementedException ();
        }
        
        public string LookupNamespace (string prefix) {
            if (prefix == "android") {
                return "http://schemas.android.com/apk/res/android";
            }
            throw new NotImplementedException ();
        }
        
        public string LookupPrefix (string ns) {
            throw new NotImplementedException ();
        }
        
#endregion
    }
}

