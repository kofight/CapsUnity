//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using Ninject;
using NUnit.Framework;
using System;
using Unibill.Impl;
using Unibill;

namespace Tests
{
    [TestFixture]
    public class testBiller : BaseInjectedTest
    {
        private PurchasableItem CONSUMABLE, NON_CONSUMABLE;
        private string CONSUMABLE_ID, NON_CONSUMABLE_ID;

        [TestFixtureSetUp]
        public void testSetup () {
            setup();
            InventoryDatabase db = kernel.Get<InventoryDatabase>();
            CONSUMABLE = db.AllConsumablePurchasableItems[0];
            NON_CONSUMABLE = db.AllNonConsumablePurchasableItems[0];
            ProductIdRemapper remapper = kernel.Get<ProductIdRemapper>();
            CONSUMABLE_ID = remapper.mapItemIdToPlatformSpecificId(CONSUMABLE);
            NON_CONSUMABLE_ID = remapper.mapItemIdToPlatformSpecificId(NON_CONSUMABLE);
        }

        [Test]
        public void testPurchaseFails() {
            var biller = instantiateAndInitialiseBiller();
            biller.onPurchaseFailedEvent(CONSUMABLE_ID);
            Assert.AreEqual(0, biller.getPurchaseHistory(CONSUMABLE));
        }

        [Test]
        public void testPurchaseSucceeds() {
            var biller = instantiateAndInitialiseBiller();
            biller.onPurchaseSucceeded(CONSUMABLE_ID);
            Assert.AreEqual(1, biller.getPurchaseHistory(CONSUMABLE));
        }

        [Test]
        public void testConsumablePurchaseCanBeMultiPurchased() {
            var biller = instantiateAndInitialiseBiller();
            biller.onPurchaseSucceeded(CONSUMABLE_ID);
            biller.onPurchaseSucceeded(CONSUMABLE_ID);
            Assert.AreEqual(2, biller.getPurchaseHistory(CONSUMABLE));
        }

        [Test]
        public void testNonConsumablePurchaseCannotBeMultiPurchased() {
            var biller = instantiateAndInitialiseBiller();
            biller.onPurchaseSucceeded(NON_CONSUMABLE_ID);
            biller.onPurchaseSucceeded(NON_CONSUMABLE_ID);
            Assert.AreEqual(1, biller.getPurchaseHistory(NON_CONSUMABLE));
        }

        [Test]
        public void testCanPurchaseOnceBillingSubsystemReportsReadiness () {
            var biller = instantiateAndInitialiseBiller ();
            biller.onSetupComplete(true);
            biller.purchase(CONSUMABLE);
        }

        [Test]
        public void testPurchaseCancelled () {
            var biller = instantiateAndInitialiseBiller();
            biller.onSetupComplete(true);
            biller.onPurchaseCancelledEvent(CONSUMABLE_ID);
        }

        [Test]
        public void testPurchaseRefundedDecrementsTransactionCount () {
            var biller = instantiateAndInitialiseBiller();
            biller.onSetupComplete(true);
            biller.onPurchaseSucceeded(NON_CONSUMABLE_ID);
            biller.onPurchaseRefundedEvent(NON_CONSUMABLE_ID);
            Assert.AreEqual(0, biller.getPurchaseHistory(CONSUMABLE));
        }

        [Test]
        public void testBillerWillNotPurchaseIfBillingSystemNotReady () {
            var biller = kernel.Get<Biller>();
            FakeBillingService fake = (FakeBillingService) biller.billingSubsystem;
            biller.purchase(biller.InventoryDatabase.AllPurchasableItems[0]);
            Assert.IsFalse(fake.purchaseCalled);
        }

        [Test]
        public void testBillerWillNotRestorePurchasesIfBillingSystemNotReady () {
            var biller = kernel.Get<Biller>();
            FakeBillingService fake = (FakeBillingService) biller.billingSubsystem;
            biller.restoreTransactions();
            Assert.IsFalse(fake.restoreCalled);
        }

        [Test]
        public void testPurchasingUnknownItem() {
            var biller = kernel.Get<Biller>();
            biller.purchase("does.not.exist");
        }

        [Test]
        public void testCannotRecoverFromCriticalError() {
            var biller = kernel.Get<Biller>();
            biller.onSetupComplete(false);
            biller.logError(UnibillError.GOOGLEPLAY_BILLING_UNAVAILABLE);
            Assert.IsFalse(biller.Ready);
            biller.purchase(biller.InventoryDatabase.AllConsumablePurchasableItems[0]);
            Assert.AreEqual(0, biller.getPurchaseHistory(biller.InventoryDatabase.AllConsumablePurchasableItems[0]));
        }

        [Test]
        public void testRaisesErrorOnPurchaseUnknownProduct () {
            var biller = kernel.Get<Biller>();
            biller.onPurchaseSucceeded("does.not.exist");
            Assert.AreEqual(1, biller.Errors.Count);
        }

        [Test]
        public void testRaisesErrorOnFailedUnknownProduct () {
            var biller = kernel.Get<Biller>();
            biller.onPurchaseFailedEvent("does.not.exist");
            Assert.AreEqual(1, biller.Errors.Count);
        }

        [Test]
        public void testRaisesErrorOnRefundUnknownProduct () {
            var biller = kernel.Get<Biller>();
            biller.onPurchaseRefundedEvent("does.not.exist");
            Assert.AreEqual(1, biller.Errors.Count);
        }

        [Test]
        public void testRaisesErrorOnCancelUnknownProduct () {
            var biller = kernel.Get<Biller>();
            biller.onPurchaseCancelledEvent("does.not.exist");
            Assert.AreEqual(1, biller.Errors.Count);
        }
    }
}
