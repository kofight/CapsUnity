//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using Ninject;
using NUnit.Framework;
using Unibill.Impl;

namespace Tests {
    public class testGooglePlayCSVGenerator : BaseInjectedTest {

        [Test]
        public void testInventory() {
            GooglePlayCSVGenerator generator = kernel.Get<GooglePlayCSVGenerator>();
            generator.serialiseItem(kernel.Get<InventoryDatabase>().AllNonConsumablePurchasableItems[0]);
            generator.writeCSV();
        }
    }
}
