//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using Unibill;
using Unibill.Impl;
using Uniject;
using NUnit.Framework;
using Ninject;
using Moq;

namespace Tests {
    public class testGooglePlayIntegration : BaseInjectedTest {

        [Test]
        public void testInitialise() {
            var biller = instantiateAndInitialiseBiller();
            getService().onBillingSupportedResponse(true, "inapp");

            Assert.IsTrue(biller.Ready);
            Assert.AreEqual(0, biller.Errors.Count);
        }

        [Test]
        public void testInAppBillingNotSupported () {
            var biller = instantiateAndInitialiseBiller();
            getService().onBillingSupportedResponse(false, "inapp");

            Assert.IsFalse(biller.Ready);
            Assert.AreEqual(1, biller.Errors.Count);
        }

        [Test]
        public void testProductPurchased () {
            var biller = instantiateAndInitialiseBiller();
            getService().onBillingSupportedResponse(true, "inapp");

            var item = biller.InventoryDatabase.AllConsumablePurchasableItems[0];
            biller.purchase(item);
            Assert.AreEqual(1, biller.getPurchaseHistory(item));
        }

        [Test]
        public void testPublicKeyInvalid () {
            var biller = instantiateAndInitialiseBiller();
            ((GooglePlayBillingService) biller.billingSubsystem).onInvalidPublicKey("goat");
            Assert.IsFalse(biller.Ready);
            Assert.AreEqual(BillerState.INITIALISED_WITH_CRITICAL_ERROR, biller.State);
            Assert.AreEqual(1, biller.Errors.Count);
        }

        private GooglePlayBillingService getService () {
            return (GooglePlayBillingService) kernel.Get<Biller>().billingSubsystem;
        }

        protected override Ninject.Modules.NinjectModule getOverrideModule () {
            return new GooglePlayTestModule(false);
        }
    }
}

