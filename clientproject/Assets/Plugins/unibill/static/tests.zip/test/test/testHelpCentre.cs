//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using NUnit.Framework;
using Ninject;
using Unibill.Impl;

namespace Tests {
    public class testHelpCentre : BaseInjectedTest {

        [Test]
        public void testAllMessagesPresent () {
            HelpCentre c = kernel.Get<HelpCentre>();
            foreach (UnibillError error in Enum.GetValues(typeof(UnibillError))) {
                c.getMessage(error);
            }
        }
    }
}

