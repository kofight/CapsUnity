//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using NUnit.Framework;
using Ninject;
using System;
using System.Xml.Linq;
using Unibill.Impl;

namespace Tests {

    [TestFixture]
    public class testInventoryDatabase : BaseInjectedTest {

        public const string TEST_CONSUMABLE_ID = "com.outlinegames.100goldcoins";

        [Test]
        public void testBrowseConsumableItems () {
            PurchasableItem item = getDatabase().AllConsumablePurchasableItems[0];
            Assert.AreEqual("com.outlinegames.100goldcoins", item.Id);
        }

        [Test]
        public void testBrowseNonConsumableItems () {
            PurchasableItem item = getDatabase().AllNonConsumablePurchasableItems[0];
            Assert.AreEqual("com.outlinegames.sword", item.Id);
        }

        [Test]
        public void testBrowseAllItems () {
            Assert.GreaterOrEqual(getDatabase().AllPurchasableItems.Count, 2);
        }

        [Test]
        public void testBrowseAllSubscriptions () {
            PurchasableItem item = getDatabase().AllSubscriptions[0];
            Assert.AreEqual(PurchaseType.Subscription, item.PurchaseType);
            Assert.AreEqual("com.outlinegames.premiumsubscription", item.Id);
        }

        [Test]
        public void testUnknownItemIsNull () {
            Assert.Null(getDatabase().getItemById("does.not.exist"));
        }

        [Test]
        public void testFetchItemById () {
            PurchasableItem item = getDatabase().getItemById("com.outlinegames.100goldcoins");
            Assert.AreEqual(PurchaseType.Consumable, item.PurchaseType);
        }

        [Test]
        public void testUnibillConfig() {
            var config = kernel.Get<UnibillConfiguration>();
            Assert.AreEqual("Unibill", config.iOSSKU);
        }

        public InventoryDatabase getDatabase () {
            return kernel.Get<InventoryDatabase>();
        }
    }
}
