//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using NUnit.Framework;
using Ninject;
using Unibill;
using Unibill.Impl;

namespace Tests {

    public class testPublicInterface : BaseInjectedTest {

        [Test]
        public void testInitialisationOK() {
            UnibillState state = UnibillState.CRITICAL_ERROR;
            Unibiller.onBillerReady += (s) => state = s;
            initialiseUnibill();
            Assert.AreEqual(UnibillState.SUCCESS, state);
        }

        [Test]
        public void testInitialisationWithErrors() {
            getFakeService().reportError = true;
            UnibillState state = UnibillState.CRITICAL_ERROR;
            Unibiller.onBillerReady += (s) => state = s;
            initialiseUnibill();
            Assert.AreEqual(UnibillState.SUCCESS_WITH_ERRORS, state);
            Assert.AreEqual(1, Unibiller.Errors.Length);
        }

        [Test]
        public void testInitWithCriticalError() {
            getFakeService().reportCriticalError = true;
            UnibillState state = UnibillState.SUCCESS;
            Unibiller.onBillerReady += (s) => state = s;
            initialiseUnibill();
            Assert.AreEqual(UnibillState.CRITICAL_ERROR, state);
        }

        [Test]
        public void testFetchAllProducts () {
            initialiseUnibill();
            Assert.AreEqual(4, Unibiller.AllPurchasableItems.Length);
        }

        [Test]
        public void testFetchAllNonConsumable () {
            initialiseUnibill();
            Assert.AreEqual(2, Unibiller.AllNonConsumablePurchasableItems.Length);
        }

        [Test]
        public void testFetchAllConsumable () {
            initialiseUnibill();
            Assert.AreEqual(1, Unibiller.AllConsumablePurchasableItems.Length);
        }

        [Test]
        public void testFetchAllSubscriptions () {
            initialiseUnibill();
            Assert.AreEqual(1, Unibiller.AllSubscriptions.Length);
        }

        [Test]
        public void testPurchase () {
            PurchasableItem purchase = null;
            Unibiller.onPurchaseComplete += (p) => purchase = p;
            initialiseUnibill();
            Unibiller.initiatePurchase(Unibiller.AllConsumablePurchasableItems[0]);
            Assert.AreEqual(Unibiller.AllPurchasableItems[0], purchase);
        }

        [Test]
        public void testPurchaseUsingId() {
            PurchasableItem purchase = null;
            Unibiller.onPurchaseComplete += (p) => purchase = p;
            initialiseUnibill();
            Unibiller.initiatePurchase("com.outlinegames.100goldcoins");
            Assert.AreEqual(Unibiller.AllPurchasableItems[0], purchase);
        }

        [Test]
        public void testGetPurchaseCount() {
            initialiseUnibill();
            Assert.AreEqual(0, Unibiller.GetPurchaseCount(Unibiller.AllPurchasableItems[0]));
            Unibiller.initiatePurchase(Unibiller.AllPurchasableItems[0]);
            Assert.AreEqual(1, Unibiller.GetPurchaseCount(Unibiller.AllPurchasableItems[0]));
        }

        [Test]
        public void testGetPurchaseCountById() {
            initialiseUnibill();
            Assert.AreEqual(0, Unibiller.GetPurchaseCount(Unibiller.AllPurchasableItems[0]));
            Unibiller.initiatePurchase(Unibiller.AllPurchasableItems[0].Id);
            Assert.AreEqual(1, Unibiller.GetPurchaseCount(Unibiller.AllPurchasableItems[0]));
        }

        [Test]
        public void testRestoreTransactions() {
            bool success = false;
            Unibiller.onTransactionsRestored += (b) => success = b;
            initialiseUnibill();
            Unibiller.restoreTransactions();
            Assert.True(success);
        }

        [Test]
        public void testLookupPurchasableItemById() {
            initialiseUnibill();
            PurchasableItem item = Unibiller.GetPurchasableItemById("com.outlinegames.100goldcoins");
            Assert.AreEqual(PurchaseType.Consumable, item.PurchaseType);
        }

        private void initialiseUnibill() {
            Unibiller._internal_doInitialise(kernel.Get<Biller>());
        }

        private FakeBillingService getFakeService() {
            return (FakeBillingService) kernel.Get<IBillingService>();
        }
    }
}
