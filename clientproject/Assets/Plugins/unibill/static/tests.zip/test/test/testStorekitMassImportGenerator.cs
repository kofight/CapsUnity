//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using Ninject;
using Unibill;
using Unibill.Impl;
using NUnit.Framework;

namespace Tests {

    public class testStorekitMassImportGenerator : BaseInjectedTest {

        [Test]
        public void testSerialiseConsumable() {
            //SKU   Product ID  Reference Name  Type    Cleared For Sale    Wholesale Price Tier    Displayed Name  Description Screenshot Path Effective Date  End Date    Review Notes    Hosted Content Path
            StorekitMassImportTemplateGenerator generator = kernel.Get<StorekitMassImportTemplateGenerator>();
            string result = generator.serialisePurchasable(kernel.Get<InventoryDatabase>().AllConsumablePurchasableItems[0]);
            string[] splits = result.Split('\t');
            Assert.AreEqual("Consumable", splits[3]);
        }

        [Test]
        public void testSerialiseNonConsumable() {
            //SKU   Product ID  Reference Name  Type    Cleared For Sale    Wholesale Price Tier    Displayed Name  Description Screenshot Path Effective Date  End Date    Review Notes    Hosted Content Path
            StorekitMassImportTemplateGenerator generator = kernel.Get<StorekitMassImportTemplateGenerator>();
            string result = generator.serialisePurchasable(kernel.Get<InventoryDatabase>().AllNonConsumablePurchasableItems[0]);
            string[] splits = result.Split('\t');
            Assert.AreEqual("Non-Consumable", splits[3]);
        }

        [Test]
        public void testFileWriting() {
            kernel.Get<StorekitMassImportTemplateGenerator>().writeFile();
        }
    }
}
