//-----------------------------------------------------------------
//  Copyright 2013 Alex McAusland and Ballater Creations
//  All rights reserved
//  www.outlinegames.com
//-----------------------------------------------------------------
using System;
using System.Collections.Generic;
using Unibill.Impl;
using Ninject;
using NUnit.Framework;

namespace Tests {
    public class testXmlParser : BaseInjectedTest {

        [Test]
        public void testInventoryExtraction() {
            UnibillXmlParser s = kernel.Get<UnibillXmlParser>();

            List<UnibillXmlParser.UnibillXElement> result = s.Parse("unibillInventory", "item");
            Assert.LessOrEqual(2, result.Count);
            UnibillXmlParser.UnibillXElement element = result[1];

            Assert.AreEqual("com.outlinegames.sword", element.attributes["id"]);
            Assert.AreEqual("Magic Sword", element.kvps["name"]);
        }
    }
}
